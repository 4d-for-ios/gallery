<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-form-detail-TripleCircle/blob/master/template.gif" alt="Triple Circle" height="auto" width="300"></p>

## Triple Circle

* **Actions:** included
* **Image required:** yes

## How to integrate

* To use a detail form template, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/form/detail folder.
* Then drop the detail form folder into it.
