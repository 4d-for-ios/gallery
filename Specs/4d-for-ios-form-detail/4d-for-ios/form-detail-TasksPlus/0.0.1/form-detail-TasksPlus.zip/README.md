<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-form-detail-TasksPlus/blob/master/template.gif" alt="Tasks Plus" height="auto" width="300"></p>

## Tasks Plus

* **Actions:** included
* **Image required:** no

## How to integrate

* To use a detail form template, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/form/detail folder.
* Then drop the detail form folder into it.
