<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-formatter-Address/blob/master/formatter.png" alt="Phone” height="auto" width="200"></p>

## Address

* **Format:** Text ⟶ Address
* **Function:** open Map app on click
* **Type:** Swift formatter

## How to integrate

* To use a custom formatter, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/formatters folder.
* Then drop the formatter folder into it. 
